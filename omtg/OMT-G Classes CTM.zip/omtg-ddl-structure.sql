-- Create table Logradouros
CREATE TABLE Logradouros (
  idLogradouro INTEGER,
  tpLogradouro INTEGER,
  nmLogradouro INTEGER,
  nrLeiDenominacao INTEGER,
  dtIniDenominacao INTEGER,
  dtFimDenominacao INTEGER,
  outrosDados... INTEGER,
  geom MDSYS.SDO_GEOMETRY,
  CONSTRAINT pk_Logradouros PRIMARY KEY (idLogradouro)
);
/
-- Insert the geom column of Logradouros into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('Logradouros', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of Logradouros
CREATE INDEX SIDX_Logradouros ON Logradouros(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POLYGON');
/
-- Create table Distritos
CREATE TABLE Distritos (
  idDistrito VARCHAR2(7),
  nmDistrito INTEGER,
  cdIbge VARCHAR2(5),
  outrosDados... VARCHAR2(300),
  geom MDSYS.SDO_GEOMETRY,
  CONSTRAINT pk_Distritos PRIMARY KEY (idDistrito)
);
/
-- Insert the geom column of Distritos into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('Distritos', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of Distritos
CREATE INDEX SIDX_Distritos ON Distritos(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POLYGON');
/
-- Create table Setores
CREATE TABLE Setores (
  idSetor INTEGER,
  idDistrito INTEGER,
  nmSetor VARCHAR2(100),
  outrosDados... VARCHAR2(300),
  geom MDSYS.SDO_GEOMETRY,
  CONSTRAINT pk_Setores PRIMARY KEY (idSetor)
);
/
-- Insert the geom column of Setores into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('Setores', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of Setores
CREATE INDEX SIDX_Setores ON Setores(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POLYGON');
/
-- Create table Quadras
CREATE TABLE Quadras (
  idQuadra INTEGER,
  idSetor INTEGER,
  qtdLogradouros INTEGER,
  outrosDados... VARCHAR2(300),
  geom MDSYS.SDO_GEOMETRY,
  CONSTRAINT pk_Quadras PRIMARY KEY (idQuadra)
);
/
-- Insert the geom column of Quadras into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('Quadras', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of Quadras
CREATE INDEX SIDX_Quadras ON Quadras(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POLYGON');
/
-- Create table CIATA
CREATE TABLE CIATA (
  idCIATA VARCHAR2(15),
  outrosDados... VARCHAR2(300),
  CONSTRAINT pk_CIATA PRIMARY KEY (idCIATA)
);
/
-- Create table Lotes
CREATE TABLE Lotes (
  idLote INTEGER,
  idLogradouro INTEGER,
  Número INTEGER,
  dimLargura INTEGER,
  dimComprimento INTEGER,
  idCIATA VARCHAR2(15),
  outrosDados... VARCHAR2(300),
  geom MDSYS.SDO_GEOMETRY,
  CONSTRAINT pk_Lotes PRIMARY KEY (idLote)
);
/
-- Insert the geom column of Lotes into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('Lotes', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of Lotes
CREATE INDEX SIDX_Lotes ON Lotes(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POLYGON');
/
-- Create table UIs
CREATE TABLE UIs (
  idUI INTEGER,
  idLote INTEGER,
  cplmUI VARCHAR2(100),
  outrosDados... VARCHAR2(300),
  geom MDSYS.SDO_GEOMETRY,
  CONSTRAINT pk_UIs PRIMARY KEY (idUI)
);
/
-- Insert the geom column of UIs into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('UIs', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of UIs
CREATE INDEX SIDX_UIs ON UIs(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POLYGON');
/
-- Create table Municipios
CREATE TABLE Municipios (
  cdIbge VARCHAR2(7),
  nmMunicipio VARCHAR2(100),
  outrosDados... VARCHAR2(300),
  geom MDSYS.SDO_GEOMETRY,
  CONSTRAINT pk_Municipios PRIMARY KEY (cdIbge)
);
/
-- Insert the geom column of Municipios into metadata table USER_SDO_GEOM_METADATA
INSERT INTO USER_SDO_GEOM_METADATA (TABLE_NAME, COLUMN_NAME, DIMINFO, SRID)
  VALUES ('Municipios', 'geom',
    MDSYS.SDO_DIM_ARRAY
      (MDSYS.SDO_DIM_ELEMENT('X', -180.000000000, 180.000000000, 0.005),
      MDSYS.SDO_DIM_ELEMENT('Y', -90.000000000, 90.000000000, 0.005)),
    '29100');
/
-- Create the spatial index on geom column of Municipios
CREATE INDEX SIDX_Municipios ON Municipios(geom)
  INDEXTYPE IS MDSYS.SPATIAL_INDEX
  PARAMETERS ('SDO_INDX_DIMS=2, LAYER_GTYPE=POLYGON');
/
-- Add new column (foreign key) on table Distritos due conventional-relationship-Distritos--Setores
ALTER TABLE Distritos ADD (
  Setores_idSetor INTEGER
);
/
-- Add foreign key constraint on table Distritos due conventional-relationship-Distritos--Setores
ALTER TABLE Distritos ADD
  CONSTRAINT fk_Distritos_ref_Setores
  FOREIGN KEY (Setores_idSetor)
  REFERENCES Setores(idSetor);
/
-- Add new column (foreign key) on table UIs due conventional-relationship-Lotes--UIs
ALTER TABLE UIs ADD (
  Lotes_idLote INTEGER
);
/
-- Add foreign key constraint on table UIs due conventional-relationship-Lotes--UIs
ALTER TABLE UIs ADD
  CONSTRAINT fk_UIs_ref_Lotes
  FOREIGN KEY (Lotes_idLote)
  REFERENCES Lotes(idLote);
/
-- Add new column (foreign key) on table Lotes due conventional-relationship-Logradouros--Lotes
ALTER TABLE Lotes ADD (
  Logradouros_idLogradouro INTEGER
);
/
-- Add foreign key constraint on table Lotes due conventional-relationship-Logradouros--Lotes
ALTER TABLE Lotes ADD
  CONSTRAINT fk_Lotes_ref_Logradouros
  FOREIGN KEY (Logradouros_idLogradouro)
  REFERENCES Logradouros(idLogradouro);
/
-- Add new column (foreign key) on table CIATA due conventional-relationship-Lotes--CIATA
ALTER TABLE CIATA ADD (
  Lotes_idLote INTEGER
);
/
-- Add foreign key constraint on table CIATA due conventional-relationship-Lotes--CIATA
ALTER TABLE CIATA ADD
  CONSTRAINT fk_CIATA_ref_Lotes
  FOREIGN KEY (Lotes_idLote)
  REFERENCES Lotes(idLote);
/
-- Add new column (foreign key) on table Distritos due conventional-relationship-Municipios--Distritos
ALTER TABLE Distritos ADD (
  Municipios_cdIbge VARCHAR2(7)
);
/
-- Add foreign key constraint on table Distritos due conventional-relationship-Municipios--Distritos
ALTER TABLE Distritos ADD
  CONSTRAINT fk_Distritos_ref_Municipios
  FOREIGN KEY (Municipios_cdIbge)
  REFERENCES Municipios(cdIbge);
/
-- Add new column (foreign key) on table Quadras due conventional-relationship-Setores--Quadras
ALTER TABLE Quadras ADD (
  Setores_idSetor INTEGER
);
/
-- Add foreign key constraint on table Quadras due conventional-relationship-Setores--Quadras
ALTER TABLE Quadras ADD
  CONSTRAINT fk_Quadras_ref_Setores
  FOREIGN KEY (Setores_idSetor)
  REFERENCES Setores(idSetor);
/
-- Add new column (foreign key) on table Lotes due conventional-relationship-Lotes--Quadras
ALTER TABLE Lotes ADD (
  Quadras_idQuadra INTEGER
);
/
-- Add foreign key constraint on table Lotes due conventional-relationship-Lotes--Quadras
ALTER TABLE Lotes ADD
  CONSTRAINT fk_Lotes_ref_Quadras
  FOREIGN KEY (Quadras_idQuadra)
  REFERENCES Quadras(idQuadra);
/
